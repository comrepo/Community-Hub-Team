# -*- coding: utf-8 -*-
#------------------------------------------------------------
# 
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# 
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.TIA'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "LiverpoolFC"
YOUTUBE_CHANNEL_ID_2 = "ThisIsAnfieldcom"
YOUTUBE_CHANNEL_ID_3 = "WeAreTheRedMen"
YOUTUBE_CHANNEL_ID_4 = "UCXXzw4cz0ZJM6jrQdOs16eA"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR snow]Offical Liverpool FC[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-TrtEHOgcMFE/AAAAAAAAAAI/AAAAAAAAAAA/K547x_dy1bY/s900-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

 
    plugintools.add_item( 
        #action="", 
        title="[COLOR snow]This Is Anfield Official Channel[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://i.imgur.com/iLMDonf.png",
        folder=True )



    plugintools.add_item( 
        #action="", 
        title="[COLOR snow]Redmen TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-u0HNg7x_MEc/AAAAAAAAAAI/AAAAAAAAAAA/IkIfLRiRRlU/s900-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

 
    plugintools.add_item( 
        #action="", 
        title="[COLOR snow]Anfield Legend[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-I0VIXGcs3Xo/AAAAAAAAAAI/AAAAAAAAAAA/GwqDr_DjfZU/s900-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

 


run()
