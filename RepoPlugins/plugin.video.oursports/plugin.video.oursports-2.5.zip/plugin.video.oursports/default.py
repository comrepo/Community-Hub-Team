# -*- coding: utf-8 -*-

'''
    Template Add-on
    Copyright (C) 2016 Demo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
'''
import requests, urllib2, xbmcgui, urllib, xbmcplugin, re, xbmc, os, shutil, xbmcaddon, base64
from datetime import datetime
from cookielib import CookieJar
import liveresolver


ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.oursports/')
USERDATA_PATH = xbmc.translatePath('special://home/userdata/addon_data')
ADDON_DATA = USERDATA_PATH + '/plugin.video.oursports/'
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
addon_id = 'plugin.video.oursports'
ADDON = xbmcaddon.Addon(id=addon_id)
Dialog = xbmcgui.Dialog()
addons = xbmc.translatePath('special://home/addons/')
footy = 'http://footytube.com'
addon_handle = int(sys.argv[1])
search_option = ADDON_DATA+'Search.txt'

Year = datetime.now().strftime('%Y')
Month = datetime.now().strftime('%m')
Day = datetime.now().strftime('%d')
Hour = datetime.now().strftime('%H')
Minute = datetime.now().strftime('%M')
time_now_number = str((int(Hour) * 60) + int(Minute))
f4murl = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
sports = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='
ADDONS      =  xbmc.translatePath(os.path.join('special://home','addons',''))
addon_id='plugin.video.oursports'
current_folder = ADDONS+'/'+addon_id+'/'
full_file = current_folder.replace('\\','/') + '/info.txt'

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()
  TextBox()

if not os.path.exists(full_file):
    Open = open(full_file,'w+')
    TextBoxes('final.txt','A big thank you to @origin for code dm @our5port5 for any requests')



def Main_Menu():
	Menu('[COLORred]SEARCH CHANNEL[/COLOR]','',28,'','','','')
	Menu('[COLORred]TV GUIDE-UK ONLY  [/COLOR]','',2,'','','','')
	Menu('[COLORred]IPTV LINKS[/COLOR]','',3,'','','','')
	Menu('[COLORred]SHADOW NET LINKS[/COLOR]','',4,'','','','')
	Menu('[COLORred]SPORTS FIXTURES[/COLOR]','',13,'','','','')
	Menu('[COLORred]FOOTBALL REPLAYS[/COLOR]','',14,'','','','')
	if ADDON.getSetting('Search_List')=='true':
		Menu('[COLORred]FAVORITES[/COLOR]','',32,'','','','')
	
def Search():
	choices = ['[COLORred]Search for channel[/COLOR]','Search for live program - [COLORred]UK ONLY[/COLOR]']
	choice = xbmcgui.Dialog().select('Search', choices)
	if choice==0:
		Search_Ultra()
	elif choice==1:
		Search_Programme()
		
def Search_Programme():
	Search_title = Dialog.input('Search', type=xbmcgui.INPUT_ALPHANUM)
	Search_name = Search_title.lower()
	url = 'http://www.tvguide.co.uk/?catcolor=&systemid=25&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'
	WhatsOnCOUK(Search_name,url,'SEARCH_SPLIT')
	
def Search_options():

	Menu('Add a search name - then reload this menu','',33,'','','','')
	if os.path.exists(search_option):
		Open = open(search_option).read()
		match = re.compile('<NAME=>(.+?)</NAME>').findall(Open)
		for name in match:
			Menu(name,'',34,'','','','')
			
def Search_Create():
	Search_title = Dialog.input('Search', type=xbmcgui.INPUT_ALPHANUM)
	Search_name = Search_title.lower()
	if not os.path.exists(search_option):
		print_text_file_create = open(search_option,"w")
		print_text_file_create.write('<NAME=>'+Search_name+'</NAME>\n')
		print_text_file_create.close()        
	else:
		print_text_file_create = open(search_option,"a")
		print_text_file_create.write('<NAME=>'+Search_name+'</NAME>\n')
		print_text_file_create.close()        
	
def tv_guide():
    Menu('Search by channel number', '', 5, '', '', '', '')
    Menu('Popular', '7', 6, '', '', '', '')
    Menu('Freeview', '3', 6, '', '', '', '')
    Menu('Sky', '5', 6, '', '', '', '')
    Menu('Virgin XL', '25', 6, '', '', '', '')
    Menu('Freesat', '19', 6, '', '', '', '')
    Menu('BT', '22', 6, '', '', '', '')

def Todays_Sports():
    Menu('WizHD FIXTURES', '', 29, '', '', '', '')
    Menu('MamaHD FIXTURES', '', 27, '', '', '', '')
    Menu('StreamHD FIXTURES', '', 35, '', '', '', '')
	
def Streamhd():
	html = requests.get('http://www.streamhd.eu/').content
	match = re.compile('<span class="eventsmall">(.+?)</span>.+?<img src=.+?<img src="(.+?)".+?<span class="eventsmall">.+?a href="(.+?)">(.+?)</a>',re.DOTALL).findall(html)
	for time,img,url,name in match:
		url = 'http://www.streamhd.eu'+url
		Play(time+' - '+name,url,10,img,'','','')
				
def WizHDMenu(url,iconimage,fanart):
	html = requests.get('http://wizhdsports.is/').content
	block = re.compile('<ul class="sports_menu">(.+?)</ul>',re.DOTALL).findall(html)
	for item in block:
		match = re.compile('<a href="(.+?)".+?src="(.+?)".+?> (.+?)</li>').findall(str(item))
		for url2,iconimage,name in match:
			name = name.title()
			if name == 'Tv Shows':pass
			elif name == 'Others':pass
			elif name == 'P2P Online':pass
			else:
				Menu(name,url2,30,iconimage,'','','')
				
def Wiz_Get_url(url):
	List = []

	fin_date = Day+'-'+Month+'-'+Year
	html = requests.get(url).content
	block = re.compile('<h3>.+?: (.+?)</h3>(.+?)<li class=\'sports_red_bar\'>',re.DOTALL).findall(html)
	for date,rest in block:
		if date == fin_date:
			match = re.compile('<div class=\'col-md-2\'>.+?</span>(.+?)</div>.+?<div class=\'col-md-6\'>(.+?)</div>.+?div class="card-block drop_box">(.+?)<div class="card">',re.DOTALL).findall(str(rest))
			for time,teams,link_block in match:
				total = len(match)
				teams = teams.replace('  ','').replace('	','')
				link_block = link_block.replace('  ','')
				time_split = re.findall('(.+?):(.+?)-(.+?):(.+?)>',str(time+'>'))
				for start_hour,start_min,fin_hour,fin_min in time_split:
					start_no = int(start_hour)*24+int(start_min)
					fin_no = int(fin_hour)*24+int(fin_min)
					time_now = int(Hour)*24+int(Minute)
					if fin_no>time_now>start_no:
						name = '[COLORgreen]'+ teams+'[/COLOR]'
					else:
						name = teams
				link_get = re.compile("<a href='(.+?)'>.+?>(.+?)</div></a>").findall(str(link_block))
				for link,chnl in link_get:
					link = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='+link
					if len(link_get)>1:
						List.append((link,chnl))
					else:
						Play(time.replace(' ','')+'-'+name.encode('utf-8', 'ignore'),link,10,'','','','')
				if len(List)>1:
					vurl = str(List).replace('[','sublink').replace(']','#').replace('sublink(\'','sublink:').replace('plugin:','LISTSOURCE:plugin:').replace("', '",'::LISTNAME:').replace("'), ('",'::#sublink').replace("')",'').replace('sublinkLISTSOURCE','sublink:LISTSOURCE')
					xbmc.log(vurl)
					Play(time.replace(' ','')+'-'+name,vurl,31,'','','','')
					del List[:]

#hakamac
def GetSublinks(name,url,iconimage,fanart):
    xbmc.log('I GOT HERE###############')
    List=[]; ListU=[]; c=0
    all_videos = regex_get_all(url, 'sublink:', '#')
    for a in all_videos:
        if 'LISTSOURCE:' in a:
            vurl = regex_from_to(a, 'LISTSOURCE:', '::')
            linename = regex_from_to(a, 'LISTNAME:', '::')
        else:
            vurl = a.replace('sublink:','').replace('#','')
            linename = name
        if len(vurl) > 10:
            c=c+1; List.append(linename); ListU.append(vurl)
 
    if c==1:
        try:
            #print 'play 1   Name:' + name + '   url:' + ListU[0] + '     ' + str(c)
            liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=ListU[0],listitem=liz)
            xbmc.Player().play(urlsolver(ListU[0]), liz)
        except:
            pass
    else:
         dialog=xbmcgui.Dialog()
         rNo=dialog.select('Select A Source', List)
         if rNo>=0:
             rName=name
             rURL=str(ListU[rNo])
             #print 'Sublinks   Name:' + name + '   url:' + rURL
             try:
                 xbmc.Player().play(urlsolver(rURL), xbmcgui.ListItem(rName))
             except:
                 xbmc.Player().play(rURL, xbmcgui.ListItem(rName))
				 
def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r				

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
	   try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
	   except: r = ''
    else:
       try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
       except: r = ''
    return r				 

	
def Wheres_The_Match():
	HTML = OPEN_URL('http://www.wheresthematch.com/tv/home.asp')
	match = re.compile('<li><a class=".+?" href="(.+?)">(.+?)</a></li>').findall(HTML)
	for url,name in match:
		if not 'on TV' in name:
			Menu(name,url,31,'','','','')

def Wheres_The_Channel(url):
	HTML = OPEN_URL(url)
	match = re.compile('<td class="fixture-details">.+?<a class=" eventlink" href=".+?"><strong class="">(.+?)</strong></a></span>.+?<em class="">(.+?)</em>.+?class="time-channel ">.+?at (.+?) on (.+?) </span></span>',re.DOTALL).findall(HTML)
	for Sport,Name,Time,Channel in match:
		Menu(Channel+':'+Time+':'+Sport+':'+Name,'',7,'','','',Channel)
	else:
		Menu('No listing today please check back another day','','','','','','')
	
def Live_on_Sat():
	Menu('Some searchs may take a sec - if empty menu means no results','http://liveonsat.com/daily.php',25,'','','','')
	Menu('LiveOnSat Football','http://liveonsat.com/daily.php',25,'','','','')
	Menu('LiveOnSat Boxing','http://liveonsat.com/los_other_boxing.php',25,'','','','')
	Menu('LiveOnSat Rugby Union','http://liveonsat.com/los_other_rugby_U.php',25,'','','','')
	Menu('LiveOnSat FIBA','http://liveonsat.com/images/sport_fiba.jpg',25,'','','','')
	Menu('LiveOnSat NBA','http://liveonsat.com/los_US_basketball.php',25,'','','','')
	Menu('LiveOnSat Handball','http://liveonsat.com/los_other_handball.php',25,'','','','')
	Menu('LiveOnSat F1','http://liveonsat.com/los_other_motor.php',25,'','','','')
	Menu('LiveOnSat Other','http://liveonsat.com/los_other_GAA.php',25,'','','','')

	
	
def Todays_Football():
	HTML = OPEN_URL('http://www.live-footballontv.com/')
	block = re.compile('<div id="listings"><div class="container" align="center"><div class="row-fluid"><div class="span12 matchdate">(.+?)<div class="span12 matchdate">',re.DOTALL).findall(HTML)
	items = re.compile('span4 matchfixture">(.+?)</div>.+?span4 competition">(.+?)</div>.+?span1 kickofftime">(.+?)</div>.+?span3 channels">(.+?)</div>').findall(str(block))
	for name,comp,time,channels in items:
		name2 = (name).replace('&nbsp;','-').replace('---',' - ').replace('&#039;','\'').replace('&#39;','\'').replace('&amp;','&').replace('&quot;','"')
		comp2 = (comp).replace('&nbsp;','-').replace('---',' - ').replace('&#039;','\'').replace('&#39;','\'').replace('&amp;','&').replace('&quot;','"')
		channels2 = (channels).replace('&nbsp;','-').replace('-','').replace('&#039;','\'').replace('&#39;','\'').replace('&amp;','&').replace('&quot;','"')
		Menu(time+' : '+name2+' - '+channels2,channels2,26,'','',comp2,'')
		
def Live_On_Sat(url):
    HTML = OPEN_URL(url)
    game = re.compile('comp_head>(.*?)</span>.*?<div class = fLeft width = ".*?"><img src="(.*?)">.*?</div>.*?ST:(.*?)</div>(.+?)<!-- around all of channel types ENDS 2-->',re.DOTALL).findall(HTML)
    for comp,img,time,chan in game:
        channel = re.compile(",CAPTION, '(.+?)&nbsp").findall(chan)
        channel_final = (str(channel)).replace('[$]','').replace('\\xc3','n').replace('\'','').replace('[','').replace(']','').replace('\\xe2','').replace('\\x80','').replace('\\x99','').replace('\\xb1a','i')
        name = str(comp) + ' - ' + str(time)
        image = 'http://liveonsat.com' + str(img)
        Menu(name,(channel_final).replace(',','/').replace('|',''),26,image,'',channel_final,'')


def Search_Channels_Mainstream(url):
	List = []
	splitter = url + '/'
	match = re.compile('(.+?)/').findall(str(splitter))
	for url in match:
		if 'HD' in url:
			url = (url).replace('HD','')
		elif '(' in url:
			second_split = re.compile('(.+?)\(').findall(str(url))
			for item in second_split:
				url = item 
				if url not in List:
					Search_name = (url).lower()
					search_next(Search_name)
					List.append(url)
		else:
			if url not in List:
				Search_name = (url).lower()
				search_next(Search_name)
				List.append(url)		
	
def Football_Highlights():

    Menu('Footy Tube','http://www.footytube.com/leagues',16,ICON,FANART,'','')
    Menu('Latest','http://www.fullmatchesandshows.com',15,'http://www.fancyicons.com/free-icons/125/miscellaneous/png/256/football_256.png',FANART,'','')
    Menu('Shows','http://www.fullmatchesandshows.com/category/show/',15,'http://www.fm-base.co.uk/forum/attachments/club-competition-logos/3885-soccer-am-logo-socceram.png',FANART,'','')
    Menu('Premier League','http://www.fullmatchesandshows.com/premier-league/',15,'https://footballseasons.files.wordpress.com/2013/05/premier-league.png',FANART,'','')
    Menu('La Liga','http://www.fullmatchesandshows.com/la-liga/',15,'http://1.bp.blogspot.com/-c6kQ40ryhyo/U19cUlz25sI/AAAAAAAABak/qtn5chSFZm0/s1600/la-liga-logo_display_image.png',FANART,'','')
    Menu('Bundesliga','http://www.fullmatchesandshows.com/bundesliga/',15,'http://m.img.brothersoft.com/iphone/189/518670189_icon175x175.jpg',FANART,'','')
    Menu('Champions League','http://www.fullmatchesandshows.com/champions-league/',15,'http://www.ecursuri.ro/images/teste/test-champions-league.jpg',FANART,'','')
    Menu('Serie A','http://www.fullmatchesandshows.com/category/serie-a/',15,'http://files.jcriccione.it/200000223-2484526782/serie%20a.png',FANART,'','')
    Menu('Ligue 1','http://www.fullmatchesandshows.com/category/ligue-1/',15,'http://a1.mzstatic.com/us/r30/Purple5/v4/37/c7/44/37c744ae-5824-42b7-6ce0-5f471f52baab/icon180x180.jpeg',FANART,'','')

def footytube(url):
    HTML = OPEN_URL(url)
    block_and_name = re.compile('<div class="headline_xlrg color_dgray"><img align="absmiddle" height="22" src="(.+?)">(.+?)</div>').findall(HTML)
    for img,name in block_and_name:
        Menu(name,'',17,footy+img,FANART,'','')
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);	

def footytube_leagues(name):
    url = 'http://www.footytube.com/leagues'
    check = name
    HTML = OPEN_URL(url)
    block_and_name = re.compile('<div class="headline_xlrg color_dgray"><img align="absmiddle" height="22" src="(.+?)">'+name+'</div>(.+?)<div style="margin-bottom: 15px">',re.DOTALL).findall(HTML)
    for img,block in block_and_name:
        leagues = re.compile('<div>.+?<a href="(.+?)" class="standard_link">(.+?)</a><br>.+?<span class="text_xsml">(.+?)</span>.+?</div>',re.DOTALL).findall(str(block))
        for url,name,qty in leagues:
            Menu(name + ' - ' + qty,footy+url,18,ICON,FANART,'','')
        else:
            pass		
			
def footytube_teams(url):
    HTML = OPEN_URL(url)
    match = re.compile('<div class=".+?" style = ".+?"><a href="(.+?)" class=".+?" >(.+?)</a></div>').findall(HTML)
    for url,name in match:
        Menu(name,footy+url,19,ICON,FANART,'','')
        	
def footytube_videos(url):
    HTML = OPEN_URL(url)
    match = re.compile(' <div class="thumboverlay"> .+?<div><a href="(.+?)".+?<img src="(.+?)" width="165px" height="97px" /></a></div>.+?<div class="vid_title".+?class="standard_link">(.+?)</a><div class="vid_info">(.+?)</div>',re.DOTALL).findall(HTML)
    for url,img,name,age in match:
        Play(name + ' - ' + age, footy+url,20,img,FANART,'','')

		
def footytube_frame(name,url):
	HTML = OPEN_URL(url)
	match = re.compile('<iframe src="(.+?)" width=').findall(HTML)
	for url in match:
		url = footy + url
		get_footytube_PLAYlink(url)	
	match_youtube = re.compile('<iframe id="ft_player" width="100%" height="100%" src="http://www.youtube.com/embed/(.+?)?rel=0&autoplay=1&enablejsapi=1" frameborder="0" allowfullscreen></iframe>').findall(HTML)
	for url in match_youtube:
		url = 'plugin://plugin.video.youtube/play/?video_id='+url
		Big_Resolve(name,url)

def get_PLAYlink(url):
    HTML = OPEN_URL(url)
    match_youtube = re.compile('<iframe width="560" height="315" src="https://www.youtube.com/embed/(.+?)" frameborder="0" allowfullscreen>').findall(HTML)
    for url in match_youtube:
        yt.PlayVideo(url)
    match = re.compile('<script data-config="(.+?)" data-height').findall(HTML)
    for playlink in match:
        if 'div' in playlink:
            pass
        else:
            Playlink = (playlink).replace('/v2', '').replace('zeus.json', 'video-sd.mp4?hosting_id=21772').replace('config.playwire.com', 'cdn.video.playwire.com')
            Big_Resolve('Enjoy','http:'+Playlink)
		
def get_footytube_PLAYlink(url):
	HTML = OPEN_URL(url)
	match_youtube = re.compile('<iframe width="560" height="315" src="https://www.youtube.com/embed/(.+?)" frameborder="0" allowfullscreen>').findall(HTML)
	for url in match_youtube:
		url = 'plugin://plugin.video.youtube/play/?video_id='+url
		Big_Resolve(name,url)    
	match = re.compile('<script data-config="(.+?)" data-css=".+?" data-height="100%" data-width="100%" src=".+?" type="text/javascript"></script>').findall(HTML)
	for playlink in match:
		if 'div' in playlink:
			pass
		else:
			Playlink = (playlink).replace('/v2', '').replace('zeus.json', 'video-sd.mp4?hosting_id=21772').replace('config.playwire.com', 'cdn.video.playwire.com')
			Big_Resolve('Enjoy','http:'+Playlink)		
		
def Get_the_rows(url,iconimage):
    HTML = OPEN_URL(url)
    match2 = re.compile('<div class="td-module-thumb"><a href="(.+?)".+?title="(.+?)".+?"entry-thumb" src="(.+?)"').findall(HTML)
    for url,name,img in match2:
        if 'Full Match' in name:
    	    Name = name.replace('&#8211;', '-').replace('&#038;', '&').replace('&#8217;', '')
            Menu(Name,url,21,img,'','','')
        else:
    	    Name = name.replace('&#8211;', '-').replace('&#038;', '&').replace('&#8217;', '')
            Play(Name,url,23,img,'','','')
    Next = re.compile('<span class="current">.+?</span><a href="(.+?)" class="page" title=".+?">(.+?)</a>').findall(HTML)
    for url,name in Next:
        Menu('NEXT PAGE',url,22,iconimage,FANART,'','')

def get_All_Rows(url,iconimage):
    HTML = OPEN_URL(url)
    block = re.compile('<div class="td-block-span6">(.+?)<div class="td-pb-span4 td-main-sidebar">',re.DOTALL).findall(HTML)
    match2 = re.compile('<div class="td-module-thumb"><a href="(.+?)".+?title="(.+?)".+?"entry-thumb" src="(.+?)"').findall(str(block))
    for url,name,img in match2:
        if 'Full Match' in name:
    	    Name = name.replace('&#8211;', '-').replace('&#038;', '&').replace('&#8217;', '')
            Menu(Name,url,21,img,'','','')
        else:
    	    Name = name.replace('&#8211;', '-').replace('&#038;', '&').replace('&#8217;', '')
            Play(Name,url,23,img,'','','')
    Next = re.compile('<span class="current">.+?</span><a href="(.+?)" class="page" title=".+?">(.+?)</a>').findall(HTML)
    for url,name in Next:
        Menu('NEXT PAGE',url,22,iconimage,FANART,'','')
    if len(match2)<=0:
        Menu('No Replays available sorry',url,22,iconimage,FANART,'','')		
		
def get_Multi_Links(url,iconimage):
    Play('Extended Highlights',url,23,iconimage,FANART,'','')
    HTML = OPEN_URL(url)
    match = re.compile('<link href=".+?" rel="stylesheet" type="text/css"><li tabindex="0" class="button_style" id=".+?"><a href="(.+?)"><div class="acp_title">(.+?)</div></a></li>').findall(HTML)
    for url2,name in match:
        url = url+url2
        name = (name).replace('HL English','English Highlights')
        Play(name,url,23,iconimage,FANART,'','')
		
def M3u8():
	headers = {"User-Agent": "Mozilla/5.0"}
	HTML = requests.get('http://www.iptvultra.com/',headers=headers).text
	match = re.compile('<span class="link"><a href="(.+?)">(.+?)</a>').findall(HTML)
	for url, name in match:
		if 'Premium List IPTV' in name:
			pass
		else:
			Menu(name,url,12,'','','','')

def m3u8_single(url):
	headers = {"User-Agent": "Mozilla/5.0"}
	HTML = requests.get(url,headers=headers).text
	match = re.compile('".+?[@](.+?)[@].+?[@].+?[@](.+?)"').findall(HTML)
	for name,url2 in match:
		try:
			name = name.replace('[','').replace(']','')
			if name[0] == ' ':
				name = name[1:]
			if name[-1] == ' ':
				name = name[:-1]
			play_url = f4murl+url2.replace('[','').replace(']','')+';name=OUR SPORTS'
			Play(name,play_url,10,'','','','')
		except:
			pass
	
def by_country():
	HTML = requests.get('http://www.shadow-net.org').text
	match = re.compile('<li class=""><a href="(.+?)">(.+?)</a>').findall(HTML)
	for url, name in match:
		name = name.replace('&amp;','&')
		if 'p2p' in name.lower():
			pass
		else:
			Menu(name,url,8,'','','','')
			
def Mama_hd():
	html = requests.get('http://mamahd.com/').content
	block = re.compile('<div class="schedule">(.+?)<div id="pagination">',re.DOTALL).findall(html)
	for item in block:
		match = re.compile('<a href="(.+?)">.+?<img src="(.+?)">.+?<div class="home cell">.+?<img src=".+?"><span>(.+?)</span>.+?<div class="away cell">.+?<span>(.+?)</span>',re.DOTALL).findall(str(item))
		for url,img,home,away in match:
			name = home+' vs '+away
			url = sports+url
			Play(name,url,10,img,'','','')
	
freeview = [['4Music | Direct','http://llnw.live.btv.simplestream.com/coder9/coder.channels.channel6/hls/4/playlist.m3u8',1201],
	['4Music | TVPlayer','128',1202],
	['5* | FilmOn','https://www.filmon.com/tv/5-star',1201],
	['5USA | FilmOn','https://www.filmon.com/tv/5usa',1201],
	['Al Jazeera | TVPlayer','146',1202],
	['Al Jazeera | FilmOn','https://www.filmon.com/tv/al-jazeera',1201],
	['BBC Alba | TVPlayer','236',1202],
	['BBC Alba | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_1/live/bbc_alba/bbc_alba.isml/bbc_alba-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['BBC Four HD | BBC iPlayer','http://vs-hls-uk-live.akamaized.net/pool_33/live/bbc_four_hd/bbc_four_hd.isml/bbc_four_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC Four | TVPlayer','110',1202],
	['BBC Four | FilmOn','https://www.filmon.com/tv/cbeebiesbbc-four',1201],
	['BBC News HD | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_34/live/bbc_news_channel_hd/bbc_news_channel_hd.isml/bbc_news_channel_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC News | TVPlayer','111',1202],
	['BBC News | FilmOn','https://www.filmon.com/tv/bbc-news',1201],
	['BBC 1 HD | BBC iPlayer','http://vs-hls-uk-live.akamaized.net/pool_30/live/bbc_one_hd/bbc_one_hd.isml/bbc_one_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC 1 | TVPlayer','89',1202],
	['BBC 1 | FilmOn','https://www.filmon.com/tv/bbc-one',1201],
	['BBC 1 Northern Ireland | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_4/live/bbc_one_northern_ireland_hd/bbc_one_northern_ireland_hd.isml/bbc_one_northern_ireland_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC 1 Northern Ireland | FilmOn','https://www.filmon.com/tv/bbc-1-north-ireland',1201],
	['BBC 1 Scotland | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_5/live/bbc_one_scotland_hd/bbc_one_scotland_hd.isml/bbc_one_scotland_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC 1 Scotland | FilmOn','https://www.filmon.com/tv/bbc-1-scotland',1201],
	['BBC 1 Wales | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_3/live/bbc_one_wales_hd/bbc_one_wales_hd.isml/bbc_one_wales_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC 1 Wales | FilmOn','https://www.filmon.com/tv/bbc-1-wales',1201],
	['BBC 2 Northern Ireland | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_5/live/bbc_two_northern_ireland_digital/bbc_two_northern_ireland_digital.isml/bbc_two_northern_ireland_digital-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['BBC 2 Scotland | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_5/live/bbc_two_scotland/bbc_two_scotland.isml/bbc_two_scotland-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['BBC 2 Wales | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_5/live/bbc_two_wales_digital/bbc_two_wales_digital.isml/bbc_two_wales_digital-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['BBC Parliament | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_1/live/bbc_parliament/bbc_parliament.isml/bbc_parliament-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['BBC Parliament | TVPlayer','345',1202],
	['BBC Parliament | FilmOn','https://www.filmon.com/tv/bbc-parliament',1201],
	['BBC 2 HD | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_31/live/bbc_two_hd/bbc_two_hd.isml/bbc_two_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['BBC 2 | TVPlayer','90',1202],
	['BBC 2 | FilmOn','https://www.filmon.com/tv/bbc-two',1201],
	['Bloomberg | TVPlayer','514',1202],
	['Bloomberg | FilmOn','https://www.filmon.com/tv/bloomberg',1201],
	['The Box | Direct','http://llnw.live.btv.simplestream.com/coder9/coder.channels.channel12/hls/4/playlist.m3u8',1201],
	['The Box | TVPlayer','129',1202],
	['Box Hits | Direct','http://llnw.live.btv.simplestream.com/coder9/coder.channels.channel2/hls/4/playlist.m3u8',1201],
	['Box Hits | TVPlayer','130',1202],
	['Box Upfront | Direct','http://llnw.live.btv.simplestream.com/coder9/coder.channels.channel8/hls/4/playlist.m3u8',1201],
	['Box Upfront | TVPlayer','158',1202],
	['Capital TV | Direct','http://ooyalahd2-f.akamaihd.net/i/globalradio01_delivery@156521/index_656_av-p.m3u8?sd=10&rebase=on',1201],
	['Capital TV | TVPlayer','157',1202],
	['CBBC HD | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_1/live/cbbc_hd/cbbc_hd.isml/cbbc_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['CBBC | TVPlayer','113',1202],
	['CBBC | FilmOn','https://www.filmon.com/tv/cbbc',1201],
	['CBeebies HD | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_2/live/cbeebies_hd/cbeebies_hd.isml/cbeebies_hd-pa4%3d128000-video%3d5070016.m3u8',1201],
	['CBeebies | TVPlayer','114',1202],
	['CBeebies | FilmOn','https://www.filmon.com/tv/cbeebies',1201],
	['CBS Action | FilmOn','https://www.filmon.com/tv/cbs-action',1201],
	['CBS Drama | FilmOn','https://www.filmon.com/tv/cbs-drama',1201],
	['CBS Reality | FilmOn','https://www.filmon.com/tv/cbs-reality',1201],
	['CBS Reality+1 | FilmOn','https://www.filmon.com/tv/cbs-reality1',1201],
	['Channel 4 | TVPlayer','92',1202],
	['Channel 4 | FilmOn','https://www.filmon.com/tv/channel-4',1201],
	['Channel 5 | TVPlayer','93',1202],
	['Channel 5 | FilmOn','https://www.filmon.com/tv/channel-5',1201],
	['Channel AKA | Direct','http://rrr.sz.xlcdn.com/?account=AATW&file=akanew&type=live&service=wowza&protocol=http&output=playlist.m3u8',1201],
	['Channel AKA | TVPlayer','227',1202],
	['Chilled | TVPlayer','226',1202],
	['CITV | ITV Hub','http://citvliveios-i.akamaihd.net/hls/live/207267/itvlive/CITVMN/master_Main1800.m3u8',1201],
	['Clubbing TV | FilmOn','https://www.filmon.com/tv/clubbing-tv',1201],
	['Clubland | TVPlayer','225',1202],
	['CNN International | TVPlayer','286',1202],
	['Community Channel | TVPlayer','259',1202],
	['The Craft Channel | TVPlayer','554',1202],
	['Dave | TVPlayer','300',1202],
	['Dave ja vu | TVPlayer','317',1202],
	['Drama | TVPlayer','346',1202],
	['E4 | FilmOn','https://www.filmon.com/tv/e4',1201],
	['Film4 | FilmOn','https://www.filmon.com/tv/film-4',1201],
	['Food Network | TVPlayer','125',1202],
	['Food Network | FilmOn','http://www.filmon.com/tv/food-network',1201],
	['Food Network+1 | TVPlayer','254',1202],
	['Food Network+1 | FilmOn','http://www.filmon.com/tv/food-network-plus-1',1201],
	['Forces TV | TVPlayer','555',1202],
	['Heart TV | Direct','http://ooyalahd2-f.akamaihd.net/i/globalradio02_delivery@156522/master.m3u8',1201],
	['Heart TV | TVPlayer','153',1202],
	['Home | TVPlayer','512',1202],
	['Horror Channel | FilmOn','https://www.filmon.com/tv/horror-channel',1201],
	['ITV1 | ITV Hub','http://itv1liveios-i.akamaihd.net/hls/live/203437/itvlive/ITV1MN/master_Main1800.m3u8',1201],
	['ITV1 | TVPlayer','204',1202],
	['ITV1 | FilmOn','http://www.filmon.com/tv/itv1',1201],
	['ITV1+1 | FilmOn','https://www.filmon.com/tv/itv-plus-1',1201],
	['ITV2 | ITV Hub','http://itv2liveios-i.akamaihd.net/hls/live/203495/itvlive/ITV2MN/master_Main1800.m3u8',1201],
	['ITV2 | FilmOn','http://www.filmon.com/tv/itv2',1201],
	['ITV2+1 | FilmOn','https://www.filmon.com/tv/itv2-plus-1',1201],
	['ITV3 | ITV Hub','http://itv3liveios-i.akamaihd.net/hls/live/207262/itvlive/ITV3MN/master_Main1800.m3u8',1201],
	['ITV3 | FilmOn','http://www.filmon.com/tv/itv3',1201],
	['ITV3+1 | FilmOn','https://www.filmon.com/tv/itv3-plus-1',1201],
	['ITV4 | ITV Hub','http://itv4liveios-i.akamaihd.net/hls/live/207266/itvlive/ITV4MN/master_Main1800.m3u8',1201],
	['ITV4 | FilmOn','http://www.filmon.com/tv/itv4',1201],
	['ITV4+1 | FilmOn','https://www.filmon.com/tv/itv4-plus-1',1201],
	['ITVBe | ITV Hub','http://itvbeliveios-i.akamaihd.net/hls/live/219078/itvlive/ITVBE/master_Main1800.m3u8',1201],
	['ITVBe | FilmOn','http://www.filmon.com/tv/itvbe',1201],
	['The Jewellery Channel | Direct','https://d2hee8qk5g0egz.cloudfront.net/live/tjc_sdi1/bitrate1.isml/bitrate1-audio_track=64000-video=1800000.m3u8',1201],
	['The Jewellery Channel | TVPlayer','545',1202],
	['Keep It Country | TVPlayer','569',1202],
	['Kerrang! | Direct','http://llnw.live.btv.simplestream.com/coder11/coder.channels.channel4/hls/4/playlist.m3u8',1201],
	['Kerrang! | TVPlayer','133',1202],
	['Kiss | Direct','http://llnw.live.btv.simplestream.com/coder9/coder.channels.channel14/hls/4/playlist.m3u8',1201],
	['Kiss | TVPlayer','131',1202],
	['Kix! | FilmOn','https://www.filmon.com/tv/kix',1201],
	['London Live | Direct','http://bcoveliveios-i.akamaihd.net/hls/live/217434/3083279840001/master_900.m3u8',1201],
	['Magic | Direct','http://llnw.live.btv.simplestream.com/coder11/coder.channels.channel2/hls/4/playlist.m3u8',1201],
	['Magic | TVPlayer','132',1202],
	['More4 | FilmOn','https://www.filmon.com/tv/more4',1201],
	['NOW Music | Direct','http://rrr.sz.xlcdn.com/?account=AATW&file=nowmusic&type=live&service=wowza&protocol=http&output=playlist.m3u8',1201],
	['NOW Music | TVPlayer','228',1202],
	['POP | FilmOn','https://www.filmon.com/tv/pop',1201],
	['Pick | FilmOn','https://www.filmon.com/tv/pick-tv',1201],
	['QUEST | TVPlayer','327',1202],
	['QUEST | FilmOn','http://www.filmon.tv/tv/quest',1201],
	['QUEST+1 | TVPlayer','336',1202],
	['QVC Beauty | TVPlayer','250',1202],
	['QVC Extra | TVPlayer','248',1202],
	['QVC Plus | TVPlayer','344',1202],
	['QVC Style | TVPlayer','249',1202],
	['QVC | TVPlayer','247',1202],
	['Really | TVPlayer','306',1202],
	['Really | FilmOn','http://www.filmon.tv/tv/really',1201],
	['S4C | BBC iPlayer','http://vs-hls-uk-live.edgesuite.net/pool_9/live/s4cpbs/s4cpbs.isml/s4cpbs-pa3%3d96000-video%3d1604032.norewind.m3u8',1201],
	['S4C | TVPlayer','251',1202],
	['Sky News | YouTube','https://www.youtube.com/watch?v=y60wDzZt8yg',1201],
	['Tiny Pop | FilmOn','https://www.filmon.com/tv/tiny-pop',1201],
	['Travel Channel | TVPlayer','126',1202],
	['Travel Channel+1 | TVPlayer','255',1202],
	['Travel Channel+1 | FilmOn','http://www.filmon.tv/tv/travel-channel1',1201],
	['Yesterday | TVPlayer','308',1202],
	['Yesterday | FilmOn','http://www.filmon.tv/tv/yesterday',1201],
	['Yesterday+1 | TVPlayer','318',1202],
	['truTV | Direct','http://llnw.live.btv.simplestream.com/coder5/coder.channels.channel2/hls/4/playlist.m3u8',1201],
	['truTV | TVPlayer','295',1202],
	['truTV | FilmOn','http://www.filmon.tv/tv/tru-tv',1201],
	['Blaze | Direct','http://live.blaze.simplestreamcdn.com/live/blaze/bitrate1.isml/bitrate1-audio_track=64000-video=3500000.m3u8',1201]]	
	

liveonline = [['Sony SIX','http://www.liveonlinetv247.info/watch.php?title=Sony SIX&channel=sonysix'],
     ['TEN 1','http://www.liveonlinetv247.info/watch.php?title=TEN 1&channel=ten1'],
     ['Sky Sports 1','http://www.liveonlinetv247.info/skysports1.php?title=Sky Sports 1&channel=skysports1'],
     ['Sky Sports 2','http://www.liveonlinetv247.info/watch.php?title=Sky Sports 2&channel=skysports2'],
     ['Sky Sports 3','http://www.liveonlinetv247.info/watch.php?title=Sky Sports 3&channel=skysports3'],
     ['Sky Sports 4','http://www.liveonlinetv247.info/watch.php?title=Sky Sports 4&channel=skysports4'],
     ['Sky Sports 5','http://www.liveonlinetv247.info/watch.php?title=Sky Sports 5&channel=skysports5'],
     ['Sky Sports News','http://www.liveonlinetv247.info/watch.php?title=Sky Sports News&channel=skysportsnews'],
     ['Sky Sports F1','http://www.liveonlinetv247.info/watch.php?title=Sky Sports F1&channel=skysportsf1'],
     ['Sky Sports Cricket','http://www.liveonlinetv247.info/watch.php?title=Sky Sports Cricket&channel=skysportscricket'],
     ['Sky Sports Box Office','http://www.liveonlinetv247.info/watch.php?title=Sky Sports Box Office&channel=skysportsboxoffice'],
     ['BT Sport 1','http://www.liveonlinetv247.info/watch.php?title=BT Sport 1&channel=btsport1'],
     ['BT Sport 2','http://www.liveonlinetv247.info/watch.php?title=BT Sport 2&channel=btsport2'],
     ['BT Sport Europe','http://www.liveonlinetv247.info/watch.php?title=BT Sport Europe&channel=btsporteurope'],
     ['BT Sport ESPN','http://www.liveonlinetv247.info/watch.php?title=BT Sport ESPN&channel=btsportespn'],
     ['ESPN','http://www.liveonlinetv247.info/watch.php?title=ESPN&channel=espn'],
     ['Canal+ Fútbol','http://www.liveonlinetv247.info/watch.php?title=Canal%2B Fútbol&channel=canal%2Bfutbol'],
     ['Canal+ Liga','http://www.liveonlinetv247.info/watch.php?title=Canal%2B Liga&channel=canal%2Bliga'],
     ['Canal+ Sport','http://www.liveonlinetv247.info/watch.php?title=Canal%2B Sport&channel=canal%2Bsport'],
     ['Eurosport','http://www.liveonlinetv247.info/watch.php?title=Eurosport&channel=eurosport'],
     ['Eurosport 2','http://www.liveonlinetv247.info/watch.php?title=Eurosport 2&channel=eurosport2'],
     ['WWE Network','http://www.liveonlinetv247.info/watch.php?title=WWE Network&channel=wwenetwork'],
     ['Premier Sports','http://www.liveonlinetv247.info/watch.php?title=Premier Sports&channel=premiersports'],
     ['BoxNation','http://www.liveonlinetv247.info/watch.php?title=BoxNation&channel=boxnation'],
     ['Willow TV','http://www.liveonlinetv247.info/watch.php?title=Willow TV&channel=willowtv'],
     ['Fox Sports 1','http://www.liveonlinetv247.info/watch.php?title=Fox Sports 1&channel=foxsports1'],
     ['Fox Sports 2','http://www.liveonlinetv247.info/watch.php?title=Fox Sports 2&channel=foxsports2'],
     ['NBA TV','http://www.liveonlinetv247.info/watch.php?title=NBA TV&channel=nbatv'],
     ['beIN Sports News','http://www.liveonlinetv247.info/watch.php?title=beIN Sports News&channel=beinsportsnews'],
     ['beIN Sports 1','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 1&channel=beinsports1'],
     ['beIN Sports 2','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 2&channel=beinsports2'],
     ['beIN Sports 3','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 3&channel=beinsports3'],
     ['beIN Sports 4','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 4&channel=beinsports4'],
     ['beIN Sports 5','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 5&channel=beinsports5'],
     ['beIN Sports 6','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 6&channel=beinsports6'],
     ['beIN Sports 7','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 7&channel=beinsports7'],
     ['beIN Sports 8','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 8&channel=beinsports8'],
     ['beIN Sports 9','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 9&channel=beinsports9'],
     ['beIN Sports 10','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 10&channel=beinsports10'],
     ['beIN Sports 11 English','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 11 English&channel=beinsports11'],
     ['beIN Sports 12 English','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 12 English&channel=beinsports12'],
     ['beIN Sports 13 English','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 13 English&channel=beinsports13'],
     ['beIN Sports 1 France','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 1 France&channel=beinsports1france'],
     ['beIN Sports 2 France','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 2 France&channel=beinsports2france'],
     ['beIN Sports 3 France','http://www.liveonlinetv247.info/watch.php?title=beIN Sports 3 France&channel=beinsports3france'],
     ['Sky Sport 1 Italia','http://www.liveonlinetv247.info/watch.php?title=Sky Sport 1 Italia&channel=skysport1italia'],
     ['Sky Sport 2 Italia','http://www.liveonlinetv247.info/watch.php?title=Sky Sport 2 Italia&channel=skysport2italia'],
     ['Sky Sport 3 Italia','http://www.liveonlinetv247.info/watch.php?title=Sky Sport 3 Italia&channel=skysport3italia'],
     ['Sky Sport 24 Italia','http://www.liveonlinetv247.info/watch.php?title=Sky Sport 24 Italia&channel=skysport24italia'],
     ['Sky Calcio','http://www.liveonlinetv247.info/watch.php?title=Sky Calcio&channel=skycalcio'],
     ['Sky Sport MotoGP','http://www.liveonlinetv247.info/watch.php?title=Sky Sport MotoGP&channel=skysportmotogp'],
     ['Racing UK','http://www.liveonlinetv247.info/watch.php?title=Racing UK&channel=racinguk'],
     ['At The Races','http://www.liveonlinetv247.info/watch.php?title=At The Races&channel=attheraces'],
     ['LFCTV','http://www.liveonlinetv247.info/watch.php?title=LFCTV&channel=lfctv'],
     ['MUTV','http://www.liveonlinetv247.info/watch.php?title=MUTV&channel=mutv'],
     ['Chelsea TV','http://www.liveonlinetv247.info/watch.php?title=Chelsea TV&channel=chelseatv'],
     ['Motors TV','http://www.liveonlinetv247.info/watch.php?title=Motors TV&channel=motorstv'],
     ['Golf Channel','http://www.liveonlinetv247.info/watch.php?title=Golf Channel&channel=golfchannel'],
     ['Setanta Sports','http://www.liveonlinetv247.info/watch.php?title=Setanta Sports&channel=setantasports'],
     ['TSN','http://www.liveonlinetv247.info/watch.php?title=TSN&channel=tsn'],
     ['TSN2','http://www.liveonlinetv247.info/watch.php?title=TSN2&channel=tsn2'],
     ['Sport TV 1','http://www.liveonlinetv247.info/watch.php?title=Sport TV 1&channel=sporttv1'],
     ['Sport TV 2','http://www.liveonlinetv247.info/watch.php?title=Sport TV 2&channel=sporttv2'],
     ['Sport TV 3','http://www.liveonlinetv247.info/watch.php?title=Sport TV 3&channel=sporttv3'],
     ['Sport TV 4','http://www.liveonlinetv247.info/watch.php?title=Sport TV 4&channel=sporttv4'],
     ['Sport TV 5','http://www.liveonlinetv247.info/watch.php?title=Sport TV 5&channel=sporttv5'],
     ['NFL Network','http://www.liveonlinetv247.info/watch.php?title=NFL Network&channel=nflnetwork'],
     ['PTV Sports','http://www.liveonlinetv247.info/watch.php?title=PTV Sports&channel=ptvsports'],
     ['NBCSN','http://www.liveonlinetv247.info/watch.php?title=NBCSN&channel=nbcsn'],
     ['Geo Super','http://www.liveonlinetv247.info/watch.php?title=Geo Super&channel=geosuper'],
     ['Star Sports','http://www.liveonlinetv247.info/watch.php?title=Star Sports&channel=starsports'],
     ['Star Cricket','http://www.liveonlinetv247.info/watch.php?title=Star Cricket&channel=starcricket'],
     ['Sportsnet World','http://www.liveonlinetv247.info/watch.php?title=Sportsnet World&channel=sportsnetworld'],
     ['Sportsnet ONE','http://www.liveonlinetv247.info/watch.php?title=Sportsnet ONE&channel=sportsnetone'],
     ['Sportsnet Ontario','http://www.liveonlinetv247.info/watch.php?title=Sportsnet Ontario&channel=sportsnetontario'],
     ['WWE TV','http://www.liveonlinetv247.info/watch.php?title=WWE TV&channel=wwetv'],
     ['BBC One','http://www.liveonlinetv247.info/bbcone.php'],
     ['BBC Two','http://www.liveonlinetv247.info/bbctwo.php'],
     ['ITV1','http://www.liveonlinetv247.info/itv1.php'],
     ['ITV2','http://www.liveonlinetv247.info/itv2.php'],
     ['AMC','http://www.liveonlinetv247.info/amc.php'],
     ['HBO','http://www.liveonlinetv247.info/hbo.php'],
     ['HBO HD','http://www.liveonlinetv247.info/hbohd.php'],
     ['Sky Atlantic','http://www.liveonlinetv247.info/skyatlantic.php'],
     ['FOX','http://www.liveonlinetv247.info/fox.php'],
     ['FX','http://www.liveonlinetv247.info/fx.php'],
     ['AXN','http://www.liveonlinetv247.info/axn.php'],
     ['Star Movies','http://www.liveonlinetv247.info/starmovies.php'],
     ['TLC','http://www.liveonlinetv247.info/tlc.php'],
     ['Syfy','http://www.liveonlinetv247.info/syfy.php'],
     ['TNT','http://www.liveonlinetv247.info/tnt.php'],
     ['ABC','http://www.liveonlinetv247.info/abc.php'],
     ['ABC Family','http://www.liveonlinetv247.info/abcfamily.php'],
     ['CBS','http://www.liveonlinetv247.info/cbs.php'],
     ['USA Network','http://www.liveonlinetv247.info/usanetwork.php'],
     ['CW TV','http://www.liveonlinetv247.info/cwtv.php'],
     ['Star World','http://www.liveonlinetv247.info/starworld.php'],
     ['Channel 5','http://www.liveonlinetv247.info/channel5.php'],
     ['beIN Movies 1','http://www.liveonlinetv247.info/beinmovies1.php'],
     ['beIN Movies 2','http://www.liveonlinetv247.info/beinmovies2.php'],
     ['beIN Movies 3','http://www.liveonlinetv247.info/beinmovies3.php'],
     ['Sky Movies Action','http://www.liveonlinetv247.info/skymoviesaction.php?title=Sky Movies Action&channel=skymoviesaction'],
     ['Sky Movies Comedy','http://www.liveonlinetv247.info/skymoviescomedy.php?title=Sky Movies Comedy&channel=skymoviescomedy'],
     ['Sky Movies Crime','http://www.liveonlinetv247.info/watch.php?title=Sky Movies Crime&channel=skymoviescrime'],
     ['Sky Movies Disney','http://www.liveonlinetv247.info/watch.php?title=Sky Movies Disney&channel=skymoviesdisney'],
     ['Sky Movies Family','http://www.liveonlinetv247.info/watch.php?title=Sky Movies Family&channel=skymoviesfamily'],
     ['Sky Movies Premiere','http://www.liveonlinetv247.info/skymoviesaction.php?title=Sky Movies Premiere&channel=skymoviespremiere'],
     ['Sky Movies Select','http://www.liveonlinetv247.info/watch.php?title=Sky Movies Select&channel=skymoviesselect'],
     ['Sky Movies Showcase','http://www.liveonlinetv247.info/skymoviesshowcase.php?title=Sky Movies Showcase&channel=skymoviesshowcase']]

	
mamahd = [['http://livetv-free.com/sky-sports-news.php','sky sports news'],
        ['http://livetv-free.com/sky-sports-1.php','sky sports 1'],
		['http://livetv-free.com/sky-sports-2.php','sky sports 2'],
		['http://livetv-free.com/sky-sports-3.php','sky sports 3'],
		['http://livetv-free.com/sky-sports-4.php','sky sports 4'],
		['http://livetv-free.com/sky-sports-5.php','sky sports 5'],
		['http://livetv-free.com/skysportsf1.php','sky sports f1'],
		['http://livetv-free.com/btsport1.php','bt sports 1'],
		['http://livetv-free.com/btsport2.php','bt sports 2'],
		['http://livetv-free.com/btsporteurope.php','bt sports 3'],
		['http://livetv-free.com/btsportespn.php','bt sport espn'],
		['http://livetv-free.com/euro-sport.php','euro-sport'],
		['http://livetv-free.com/euro-sport-2.php','euro sport 2'],
		['http://livetv-free.com/bein-sports-1.php','bein sports 1'],
		['http://livetv-free.com/bein-sports-2.php','bein sports 2'],
		['http://livetv-free.com/bein-sports-3.php','bein sports 3'],
		['http://livetv-free.com/bein-sports-4.php','bein sports 4'],
		['http://livetv-free.com/bein-sports-5.php','bein sports 5'],
		['http://livetv-free.com/bein-sports-6.php','bein sports 6'],
		['http://livetv-free.com/bein-sports-7.php','bein sports 7'],
		['http://livetv-free.com/bein-sports-8.php','bein sports 8'],
		['http://livetv-free.com/bein-sports-9.php','bein sports 9'],
		['http://livetv-free.com/bein-sports-10.php','bein sports 10'],
		['http://livetv-free.com/bein-sports-11.php','bein sports 11'],
		['http://livetv-free.com/bein-sports-12.php','bein sports 12'],
		['http://livetv-free.com/bein-sports-13.php','bein sports 13'],
		['http://livetv-free.com/espn.php','espn'],
		['http://livetv-free.com/sky-sport-italia-1.php','sky sports italia 1'],
		['http://livetv-free.com/sky-sport-italia-2.php','sky sports italia 2'],
		['http://livetv-free.com/sky-sport-italia-3.php','sky sports italia 3'],
		['http://livetv-free.com/sky-sport-italia-24.php','sky sports italia 24'],
		['http://livetv-free.com/sky-italia-motogp.php','sky italia moto gp'],
		['http://livetv-free.com/fox-sports-1.php','fox sports 1'],
		['http://livetv-free.com/fox-sports-2.php','fox sports 2'],
		['http://livetv-free.com/box-nation.php','box nation'],
		['http://livetv-free.com/canal-futbol.php','canal futbol'],
		['http://livetv-free.com/canal-liga.php','canal liga'],
		['http://livetv-free.com/setanta-sports.php','setanta sports'],
		['http://livetv-free.com/mutv.php','MUTV'],
		['http://livetv-free.com/chelsea-tv.php','Chelsea TV'],
		['http://livetv-free.com/lfc-tv.php','LFCTV'],
		['http://livetv-free.com/nbatv.php','nba tv'],
		['http://livetv-free.com/nflnetwork.php','nfl network'],
		['http://livetv-free.com/ptvsports.php','ptv sports'],
		['http://livetv-free.com/wwetv.php','wwe '],
		['http://livetv-free.com/premier-sports.php','premier sports'],
		['http://livetv-free.com/tsn.php','tsn'],
		['http://livetv-free.com/tsn-2.php','tsn 2'],
		['http://livetv-free.com/bbcone.php','bbc 1'],
		['http://livetv-free.com/bbctwo.php','bbc 2'],
		['http://livetv-free.com/itv1.php','itv 1'],
		['http://livetv-free.com/itv2.php','itv 2'],
		['http://livetv-free.com/amc.php','amc'],
		['http://livetv-free.com/hbo.php','hbo'],
		['http://livetv-free.com/hbohd.php','hbo hd'],
		['http://livetv-free.com/sky-atlantic.php',''],
		['http://livetv-free.com/fox.php','fx'],
		['http://livetv-free.com/fx.php',''],
		['http://livetv-free.com/starmovies.php','star movies'],
		['http://livetv-free.com/tlc.php','tlc'],
		['http://livetv-free.com/syfy.php','syfy'],
		['http://livetv-free.com/tnt.php','tnt'],
		['http://livetv-free.com/abc.php','abc'],
		['http://livetv-free.com/abcfamily.php','abc family'],
		['http://livetv-free.com/cbs.php','cbs'],
		['http://livetv-free.com/usanetwork.php','usa network'],
		['http://livetv-free.com/cwtv.php','c w tv'],
		['http://livetv-free.com/star-world.php','star world'],
		['http://livetv-free.com/sky-movies-select.php','sky movies select'],
		['http://livetv-free.com/sky-movies-action.php','sky movies action'],
		['http://livetv-free.com/sky-movies-comedy.php','sky movies comedy'],
		['http://livetv-free.com/sky-movies-crime.php','sky movies crime'],
		['http://livetv-free.com/sky-movies-disney.php','sky movies disney'],
		['http://livetv-free.com/sky-movies-family.php','sky movies family'],
		['http://livetv-free.com/sky-movies-premiere.php','sky movies premiere'],
		['http://livetv-free.com/bein-movies-1.php','bein movies 1'],
		['http://livetv-free.com/bein-movies-2.php','bein movies 3'],
		['http://livetv-free.com/bein-movies-3.php','bein movies 3'], 
		['http://livetv-free.com/cartoonnetwork.php','cartoon network'],
		['http://livetv-free.com/disneychannel.php','disney channel'],
		['http://livetv-free.com/nick.php','nick'],
		['http://livetv-free.com/pogo.php','pogo'],
		['http://livetv-free.com/disneyjunior.php','disney junior'],
		['http://livetv-free.com/disneyxd.php','disney xd']]
		

shadow = [['Fox Sports 1[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/fox-sports-1-fs1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],     
		['Sky Sports 1[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/my1-sky-sports-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'], 
		['Sky Sports 1 HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/hd1-sky-sports-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'], 
		['BT Sport 3[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/bt-sport-3-live-stream-2/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/m1-sky-sports-f1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'], 
		['Arena Sport 1[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/arena-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['NFL Network[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/nfl-network-live-stream/','https://oursports.000webhostapp.com/images/icon.png'], 
		['Playboy TV [COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/playboy-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Premier Sports[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/premier-sports-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BoxNation HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/boxnation-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['USA Network[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/usa-network-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 2 HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/sky-sports-2-hd-live-stream-2/','https://oursports.000webhostapp.com/images/icon.png'],
		['Eurosport 2 HD[COLORlimegreen](mytvlive)[/COLOR] ','http://mytvlive.me/eurosport-2-hd-uk-live/','https://oursports.000webhostapp.com/images/icon.png'],				
		['Eurosport 1 HD [COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/eurosport-1-hd-uk-live/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 3[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/sky-sports-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 4[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/sky-sports-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 5[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/sky-sports-5-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Eurosport 1 HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/eurosport-1-hd-uk-live/','https://oursports.000webhostapp.com/images/icon.png'],
		['Eurosport 2 HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/eurosport-2-hd-uk-live/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports News [COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/sky-sports-news-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1 [COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/m1-sky-sports-f1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 1[COLORlimegreen](mytvlive)[/COLOR] ','http://mytvlive.me/bt-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 2[COLORlimegreen](mytvlive)[/COLOR] ','http://mytvlive.me/bt-sport-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bt Sport 3 [COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/bt-sport-europe-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],  
		['Box Nation HD[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/boxnation-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'], 
		['Premier Sports[COLORlimegreen](mytvlive)[/COLOR]','http://mytvlive.me/premier-sports-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Al Kass Sport 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/al-kass-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Al Kass Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/al-kass-sport-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Al Kass Sport 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/al-kass-sport-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Al Kass Sport 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/al-kass-sport-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Arena Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/arena-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Arena Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/arena-sport-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Arena Sport 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/arena-sport-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Arena Sport 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/arena-sport-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Arena Sport 5[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/arena-sport-5-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['At the Races[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/at-the-races-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Band Sports Brazil[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/band-sports-brazil-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-2-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-3-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 4 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-4-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 5 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-5-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 6 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-6-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 7 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-7-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 8 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-8-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 9 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-9-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 10 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-10-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 11 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-11-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports 12 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sports-12-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Bein Sports USA[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bein-sport-usa-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Benfica Tv1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/benfica-tv1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Benfica Tv2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/benfica-tv2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BoxNation[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/boxnation-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-1-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-3-live-stream-bt-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport ESPN[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-espn-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport Europe[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-europe-live-stream-2/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport Extra 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-extra-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport Extra 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/bt-sport-extra-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Canal+ FutbolV[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/canal-futbol-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Canal+ Liga HDV[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/canal-liga-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Canal+[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/canal-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Canal+ Sport France[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/canal-sport-france-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['CBS Sports Network[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/cbs-sports-network-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Chelsea Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/chelsea-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Diema Sport 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/diema-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Diema Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/diema-sport-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Digi Sports 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/digi-sports-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Digi Sports 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/digi-sports-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Digi Sports 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/digi-sports-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Digi Sports 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/digi-sports-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Dolce Sport 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/dolce-sport-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Dolce Sport 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/dolce-sport-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Dolce Sport 3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/dolce-sport-3-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Dolce Sport 4 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/dolce-sport-4-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Eir Sport 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/eir-sport-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Eir Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/eir-sport-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Espn America[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espn-america-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['ESPN2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espn2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Espn Brasil HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espn-brasil-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Espn Deportes HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espn-deportes-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['ESPN HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espn-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['ESPNU[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/espnu-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Euro Sport 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/euro-sport-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Euro Sport 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/euro-sport-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Fox Deportes[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/fox-deportes-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Fox Sports 1 USA[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/fox-sports-1-usa-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Fox Sports 2 USA[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/fox-sports-2-usa-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Juventus TV[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/juventus-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['LFC Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/lfc-tv-channel-live-stream-liverpool-tv-live/','https://oursports.000webhostapp.com/images/icon.png'],
		['Lig Tv 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/lig-tv-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Lig Tv 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/lig-tv-2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Lig Tv 3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/lig-tv-3-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Ma Chaîne Sport[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/ma-chaine-sport-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['MLB Network[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/mlb-network-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Motors Tv HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/motors-tv-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['MUTV HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/mutv-hd-live-stream-manchester-united-tv-live/','https://oursports.000webhostapp.com/images/icon.png'],
		['NBA Tv Channel[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/nba-tv-channel-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['NBCSN Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/nbcsn-tv-channel-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['NFL Network[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/nfl-network-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['NHL Network Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/nhl-network-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['PFC Internacional[COLORlimegreen](sportstvstream.me)[/COLOR] ','http://www.sportstvstream.me/pfc-internacional-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Porto Canal [COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/porto-canal-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Premier Sports[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/premier-sports-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Premium Sports HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/premium-sports-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Racing UK Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/racing-uk-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Rai Sport 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/rai-sport-1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Real Madrid TV[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/real-madrid-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Setanta Ireland[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/setanta-ireland-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Bundesliga HD 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-bundesliga-hd-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Bundesliga HD 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-bundesliga-hd-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Calcio 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-calcio-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sport 1 Italy[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sport-1-italy-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sport 2 Italy[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sport-2-italy-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-1-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-2-hd-tv-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-3-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 4 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-4-hd-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 5 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-5-hd-live-stream-2/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sky-sports-f1-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sporting Tv HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sporting-tv-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['sport klub 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['sport klub 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sport Klub 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sport Klub 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sport Klub 5[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-5-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['sport klub 6[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-klub-6-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sport.RO Tv[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-ro-tv-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SportsNet 360[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-360-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SportsNet One[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-one-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sportsnet Ontario[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-ontario-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sportsnet Pacific[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-pacific-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sportsnet West[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-west-live-stream-online/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sportsnet World[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sportsnet-world-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SPORT.TV1 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-tv1-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SPORT.TV2 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-tv2-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SPORT.TV3 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-tv3-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SPORT.TV4 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-tv4-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['SPORT.TV5 HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/sport-tv5-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Super Sport 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/super-sport-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Super Sport 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/super-sport-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Super Sport 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/super-sport-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Super Sport 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/super-sport-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Super Sport 5[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/super-sport-5-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TRT Spor HD[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/trt-spor-hd-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TSN 1[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/tsn-1-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TSN 2[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/tsn-2-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TSN 3[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/tsn-3-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TSN 4[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/tsn-4-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['TSN 5[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/tsn-5-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['WWE Network[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/wwe-network-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Ziggo Sport Select[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/ziggo-sport-select-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Ziggo Sport Voetbal[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/ziggo-sport-voetbal-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 1[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-1-live-free-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 1[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw/SkySports1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 1[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/sky1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 2[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw//SkySports2.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 2[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/sky2.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 2[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-2-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 3[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw//SkySports3.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 3[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/sky3.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 3[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-3-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 4[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-4-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 4[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/sky4.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 4[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw/SkySports4.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 5[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-5-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 5[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw//SkySports5.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports 5[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/sky5.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-formula-1-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1[COLORlimegreen](Antena)[/COLOR]','http://antenasport.eu/skysportsf1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky Sports F1[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/skyf1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 1[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/bt-sport-1-live-stream1-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 1[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw/BTSport1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 1[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/bt1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 2[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/bt-sport-2-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 2[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw/BTSport2.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 2[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/bt2.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 3[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/bt-sport-3-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 3[COLORlimegreen](livesport.pw)[/COLOR]','http://livesport.pw/BTSport3.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BT Sport 3[COLORlimegreen](sstream.net)[/COLOR]','http://sstream.net/btespn.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Foxsports 1[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/foxsports-1-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Foxsports 2[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/foxsports-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Boxnation[COLORlimegreen](mamahd)[/COLOR','http://mamahd.com/box-nation-live-streaming-free-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['NFL Network[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/nfl-network-live-stream-free-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky HD1 DE[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-hd1-germany-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Sky HD2 DE[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/sky-sports-hd2-germany-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['Bundesliga 1[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/watch-sky-bundesliga-1-live-streaming-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['LFCTV[COLORlimegreen](tv.b-c-e.us)[/COLOR]','http://www.tv.b-c-e.us/LFCTV.php','https://oursports.000webhostapp.com/images/icon.png'],
        ['MUTV[COLORlimegreen](tv.b-c-e.us)[/COLOR]','http://www.tv.b-c-e.us/MUTV.php','https://oursports.000webhostapp.com/images/icon.png'],	
    	['Chelsea TV[COLORlimegreen](tv.b-c-e.us)[/COLOR]','http://www.tv.b-c-e.us/ChelseaTV.php','https://oursports.000webhostapp.com/images/icon.png'],	
    	['Nbcsn[COLORlimegreen](sportstvstream.me)[/COLOR]','http://www.sportstvstream.me/nbcsn-tv-channel-live-stream/','https://oursports.000webhostapp.com/images/icon.png'],
		['BeIn 1 FR[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/watch-bein-1-france-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['BeIn 2 FR[COLORlimegreen](mamahd)[/COLOR]','http://mamahd.com/watch-bein-2-france-live-stream-1.html','https://oursports.000webhostapp.com/images/icon.png'],
		['bt sports 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/bt-sport-1-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['bt sports 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/bt-sport-2-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['bt sports 3[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/bt-sport-3-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['bt espn[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/bt-sport-espn-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-1-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-2-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports 3[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-3-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports 4[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-4-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports 5[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-5-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports f1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-f1-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports mix[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-mix-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports news[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sports-news-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['ptv sports[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/ptv-sports-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['willow cricket[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/willow-cricket-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['stars sport 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/star-sports-1-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['stars sport 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/star-sports-2-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['stars sport 3[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/star-sports-3-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['stars sport 4[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/star-sports-4-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['fox sport 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/fox-sports-1-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['fox sport 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/fox-sports-2-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['ten cricket[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/ten-cricket-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['ten sport[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/ten-sports-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['ten action[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/ten-action-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['geo super live[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/geo-super-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['sony six[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sony-six-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['sony espn[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sony-espn-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['premier sports[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/premier-sports-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['eurosport 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/euro-sport-1-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['eurosport 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/euro-sport-2-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['espn[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/espn-uk-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['espn usa[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/espn-usa-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['espn 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/espn-2-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['wwe network[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/wwe-network-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky sports box office[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-box-office-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['nfl network[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/nfl-network-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['boxnation[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/box-nation-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky calcio[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-calcio-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky italia 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sport-1-italia-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky italia 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sport-2-italia-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sky italia 3[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sky-sport-3-italia-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sports net world[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sportsnet-world-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sports net one[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sportsnet-one-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['sports net ontario[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/sportsnet-ontario-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['tsn 1[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/tsn-1-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['tsn 2[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/tsn-2-live-streaming2','https://oursports.000webhostapp.com/images/icon.png'], 
		['at the races[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/at-the-race-live-streaming','https://oursports.000webhostapp.com/images/icon.png'], 
		['race uk[COLORlimegreen](crichd)[/COLOR]','http://cdn2.crichd.com/racing-uk-live-streaming','https://oursports.000webhostapp.com/images/icon.png']]



		
	 
def Search_Ultra():
	Search_title = Dialog.input('Search', type=xbmcgui.INPUT_ALPHANUM)
	Search_name = Search_title.lower()
	search_next(Search_name)
	
def search_next(name):
	try:
		Search_name = name
		headers = {"User-Agent": "Mozilla/5.0"}
		result = []
		sources = []
		Freeworld_count = []
		dp =  xbmcgui.DialogProgress()
		result.append('a')
		dp_add = int(ADDON.getSetting('Results')) / float(len(result)) * 100
		HTML = requests.get('http://www.iptvultra.com/',headers=headers).text
		match = re.compile('<span class="link"><a href="(.+?)">(.+?)</a>').findall(HTML)
		dp.create('Checking for stream - '+Search_name)
		dp.update(int(dp_add),'You can always cancel if you\'re happy with results',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
		if ADDON.getSetting('Live_Online')=='true':
			dp.update(int(dp_add),'Checking Live Online',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
				for thing in liveonline:
					name = thing[0]
					url = sports+thing[1]
					if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
						if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
							result.append(url[0])
							Play('[COLORred]LIVE ONLINE |[/COLOR] '+name,url,10,'','','','')
			else:
				pass
		if ADDON.getSetting('Shadow')=='true':
			dp.update(int(dp_add),'Checking Shadow',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):
				for item in shadow:
					name = item[0]
					url = item[1]
					image = item[2]
					if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
						if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
							result.append(url[0])
							Play('[COLORred]WEB LINK |[/COLOR] '+name,url,9,image,'','','')
			else:
				pass
		if ADDON.getSetting('Freeview')=='true':
			dp.update(int(dp_add),'Checking Freeview',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):
				for object in freeview:
					playlink = object[1]
					name = object[0]
					playlink = object[1]
					mode = object [2]
					if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
						if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
							result.append(playlink[0])
							try:
								addLink('[COLORred]FREEE VIEW | [/COLOR]'+name,playlink,mode,'')
							except:
								pass
								
				
			
			else:
				pass
		if ADDON.getSetting('Mama_HD')=='true':
			dp.update(int(dp_add),'Checking Mama HD',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):
				for list_item in mamahd:
					link = list_item[0]
					name = list_item[1]
					if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
						if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
							result.append(url[0])
							Play('[COLORred]LIVE TV FREE | [/COLOR]'+name,sports+link,10,'','','','')
			else:
				pass   
		if ADDON.getSetting('Freeworld')=='true':
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
				HTML6 = OPEN_URL('http://freeworldwideiptv.com/')
				match6 = re.compile('<h2 class="title">.+?<a href="(.+?)"',re.DOTALL).findall(HTML6)
				for URL in match6:
					dp.update(int(dp_add),'Checking Freeworld '+str(len(Freeworld_count))+'/'+str(len(match6)),str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
					Freeworld_count.append(URL[0])
					HTML7 = requests.get(URL.replace('https','http')).content
					match7 = re.compile('EXTINF:.+?,(.+?)\n(.+?)\n#').findall(HTML7)
					for final_name,fin_url in match7:
						if (Search_name).replace(' ','').replace('sports','sport') in (final_name).lower().replace(' ','').replace('sports','sport'):
							if int(len(result)-1)<= int(ADDON.getSetting('Results')):		
								result.append(fin_url[0])
								fin_url = f4murl+fin_url
								Play('Freeworld | '+final_name,fin_url,10,'','','','')
			else:
				pass
		if ADDON.getSetting('IPTVsat')=='true':
			dp.update(int(dp_add),'Checking IPTVsat',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):
				HTML2 = OPEN_URL('http://www.iptvsat.com/')
				match2 = re.compile("<h2 class='post-title entry-title.+?<a href='(.+?)'>(.+?)</a>",re.DOTALL).findall(HTML2)
				for url,name in match2:
					HTML3 = OPEN_URL(url)
					match3 = re.compile('#EXTINF:-1,(.+?)</h4>\n<h4 style="clear: both; text-align: center;">\n(.+?)</h4>').findall(HTML3)
					for name2,url2 in match3:
						if (Search_name).replace(' ','').replace('sports','sport') in (name2).lower().replace(' ','').replace('sports','sport'):
							result.append(url[0])
							Play('IPTVSat | '+name2,f4murl+link,10,'','','','')
			else:
				pass
		if ADDON.getSetting('IPTVUrl')=='true':
			dp.update(int(dp_add),'Checking IPTVUrl',str(len(result)-1)+'/'+str(int(ADDON.getSetting('Results')))+' Results')
			if int(len(result)-1)<= int(ADDON.getSetting('Results')):
				HTML4 = OPEN_URL('http://www.iptvurllist.com/')
				match4 = re.compile('<h1><a href="(.+?)">').findall(HTML4)
				for new_url in match4:
					fin_url = 'http://www.iptvurllist.com/'+new_url
					HTML5 = OPEN_URL(fin_url)
					match5 = re.compile('EXTINF:.+?,(.+?)\n(.+?)\n').findall(HTML5)
					for name,url5 in match5:
						if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
							result.append(url[0])
							Play('IPTVUrl | '+name,f4murl+url5,10,'','','','')
			else:
				pass
		if ADDON.getSetting('Ingenious')=='true':
			for url, name in match:
				try:
					sources.append(url[0])
					if int(len(sources))<= int(ADDON.getSetting('Sources')) and int(len(result)-1)<= int(ADDON.getSetting('Results')):
						dp.update(int(dp_add),'Checking Ingenious list '+str(len(sources))+'/'+str(int(ADDON.getSetting('Sources'))),str(len(result))+'/'+str(int(ADDON.getSetting('Results')))+' Results')
						if dp.iscanceled():
							return
						HTML2 = requests.get(url,headers=headers).text
						match2 = re.compile('".+?[@](.+?)[@].+?[@].+?[@](.+?)"').findall(HTML2)
						for name,url2 in match2:
							name = name.replace('[','').replace(']','')
							if name[0] == ' ':
								name = name[1:]
							elif name[-1] == ' ':
								name = name[:-1]
							playlink = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+url2.replace('[','').replace(']','')+';name=OUR SPORTS'
							if (Search_name).replace(' ','').replace('sports','sport') in (name).lower().replace(' ','').replace('sports','sport'):
								result.append(url[0])
								try:
									Play('Ingenious | '+name,playlink,10,'','','','')
								except:
									pass
					else:
						pass
				except:
					pass
	except:
		pass

def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

			
def get_shadow_next(Search_name,next_url):
	HTML2 = requests.get(next_url).text
	block = re.compile('<ul class="ProductList  Clear" >(.+?)<br class="Clear" />',re.DOTALL).findall(HTML2)
	for thing in block:
		match2 = re.compile('<div class="ProductImage">.+?<a href="(.+?)".+?img src="(.+?)" alt="(.+?)" />',re.DOTALL).findall(str(thing.encode('utf-8')))
		for url,image,name in match2:
			if (Search_name).replace(' ','') in (name).replace(' ','').lower():
				Play('Shadow | '+name,url,9,image,'','','')
	
	

def freeview_play(url):
	resolved = liveresolver.resolve(url)
	item = xbmcgui.ListItem(path=resolved)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)				

def tvplayer(name,url):
    import re,urllib,json
    watchHtml=open_url("http://tvplayer.com/watch/")
    channelid=url#re.findall('resourceId = "(.*?)"' ,watchHtml)[0]
    validate=re.findall('var validate = "(.*?)"' ,watchHtml)[0]

    cj = CookieJar()
    data = urllib.urlencode({'service':'1','platform':'website','token':'null','validate':validate ,'id' : channelid})
    headers={'Referer':'http://tvplayer.com/watch/','Origin':'http://tvplayer.com','User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'}
    retjson=open_url("http://api.tvplayer.com/api/v2/stream/live",data=data, headers=headers,cj=cj);
    jsondata=json.loads(retjson)
    #    print cj
    cj = CookieJar()
    playurl=jsondata["tvplayer"]["response"]["stream"]
    open_url(playurl, headers=headers,cj=cj);
    playurl=playurl+'|Cookie=%s&User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36&X-Requested-With=ShockwaveFlash/22.0.0.209&Referer=http://tvplayer.com/watch/'%getCookiesString(cj)
    Big_Resolve(name,playurl)
    return	
	
def open_url(url,data=None,headers=None, cj=None):
    cookie_handler = urllib2.HTTPCookieProcessor(cj)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
        
    req = urllib2.Request(url)

    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    if headers:
        for h in headers:
            req.add_header(h, headers[h])
    response = opener.open(req,data=data)
    link=response.read()
    response.close()
    return link
	
def getCookiesString(cookieJar):
    try:
        cookieString=""
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: pass
    #print 'cookieString',cookieString
    return cookieString
	
def Select_Type():
    choices = ['Select by Virgin No.', 'Select by Sky No.', 'Select by Freeview No.']
    choice = xbmcgui.Dialog().select('Search by channel number', choices)
    if choice == 0:
        find_channel(
            'http://www.tvguide.co.uk/?catcolor=&systemid=25&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323',
            'Virgin')
    if choice == 1:
        find_channel(
            'http://www.tvguide.co.uk/?catcolor=&systemid=5&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323',
            'Sky')
    if choice == 2:
        find_channel(
            'http://www.tvguide.co.uk/?catcolor=&systemid=3&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323',
            'Freeview')
					

def find_channel(url, name):
    channel_no = xbmcgui.Dialog().input("Channel No", type=xbmcgui.INPUT_NUMERIC)
    html = requests.get(url).text
    match = re.compile('qt-text="(.+?)" title="(.+?)"').findall(html)
    for number, channel_name in match:
        channel_name = channel_name.replace(' TV listings', '')
        number = number.replace('Channel Numbers<br> ', '')
        if ':' in number:
            if name == 'Sky':
                sky_no = re.compile('Sky:(.+?) ').findall(str(number))
                for item in sky_no:
                    if channel_no in sky_no:
                        WhatsOnCOUK('',url, str(channel_name))
            elif name == 'Virgin':
                virgin_no = re.compile('Virgin:(.+?) ').findall(str(number))
                for item in virgin_no:
                    if channel_no in virgin_no:
                        WhatsOnCOUK('',url, str(channel_name))
            elif name == 'Freeview':
                freeview_no = re.compile('Freeview:(.+?) ').findall(str(number))
                for item in freeview_no:
                    if channel_no in freeview_no:
                        WhatsOnCOUK('',url, str(channel_name))			

def tvguide_co_uk(url):
    List = [['All','http://www.tvguide.co.uk/?catcolor=&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Comedy','http://www.tvguide.co.uk/?catcolor=3253CF&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Sports','http://www.tvguide.co.uk/?catcolor=53CE32&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Music','http://www.tvguide.co.uk/?catcolor=FF9933&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Film','http://www.tvguide.co.uk/?catcolor=000000&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Soap','http://www.tvguide.co.uk/?catcolor=AB337D&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Kids','http://www.tvguide.co.uk/?catcolor=E3BB00&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Drama','http://www.tvguide.co.uk/?catcolor=CE3D32&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Talk show','http://www.tvguide.co.uk/?catcolor=800000&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Game show','http://www.tvguide.co.uk/?catcolor=669999&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Sci-fi','http://www.tvguide.co.uk/?catcolor=666699&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Documentary','http://www.tvguide.co.uk/?catcolor=CCCCCC&systemid=' + url + '&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Motor','http://www.tvguide.co.uk/?catcolor=996633&systemid=7&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323'],
            ['Horror','http://www.tvguide.co.uk/?catcolor=666633&systemid=7&thistime=' + Hour + '&thisDay=' + Month + '/' + Day + '/' + Year + '&gridspan=03:00&view=0&gw=1323']]
    for item in List:
        name = item[0]
        list_url = item[1]
        Menu(name, list_url, 11, '', '', '', '')

def Get_Channel(url):
	List = []
	HTML = requests.get(url).text
	block = re.compile('<div class="Block CategoryContent Moveable Panel"(.+?)<br class="Clear" />',re.DOTALL).findall(HTML)
	for item in block:
		match = re.compile('<div class="ProductImage">.+?<a href="(.+?)".+?img src="(.+?)" alt="(.+?)" />',re.DOTALL).findall(str(item.encode('utf-8')))
		for url,image,name in match:
			Play(name,url,9,image,'','','')
	next = re.compile('<div class="FloatRight"><a href="(.+?)">.+?</a>').findall(HTML)
	for url in next:
		if 'skippy' not in List:
			Menu('Next Page',url,8,'','','','')
			List.append('skippy')
			
def Get_Playlink(name,url):
	playlink = sports + url
	HTML = requests.get(url).text
	m3u8 = re.compile('<source src="(.+?)"').findall(HTML)
	for item in m3u8:
		playlink = item
	Big_Resolve(name,playlink)


def WhatsOnCOUK(url,extra):
    Pass_List = []
    try:
        html = requests.get(url).text
        channel_block = re.compile('<div class="div-epg-channel-progs">.+?<div class="div-epg-channel-name">(.+?)</div>(.+?)</div></div></div>',re.DOTALL).findall(html)
        for channel, block in channel_block:
            prog = re.compile('<a qt-title="(.+?)".+?<br>(.+?)<br>.+?</div>(.+?)<br>', re.DOTALL).findall(str(block.encode('utf-8')))
            for show_info, show_no, info in prog:
                show_no = show_no.replace('</div>','')
                info = info.replace('</div>','').replace('</a>','')
                if 'href' in info:
                    change = re.compile('(.+?)href').findall(str(info))
                    for thing in change:
                        info = thing					
                time_finder = re.compile('(.+?)-(.+?) ').findall(str(show_info))
                for start, finish in time_finder:
                    if 'am' in start:
                        time_split = re.compile('(.+?):(.+?)am').findall(str(start))
                        for hour, minute in time_split:
                            start_number = (int(hour) * 60) + int(minute)
                    elif 'pm' in start:
                        time_split = re.compile('(.+?):(.+?)pm').findall(str(start))
                        for hour, minute in time_split:
                            if hour == '12':
                                start_number = (int(hour) * 60) + int(minute)
                            else:
                                start_number = (int(hour) + 12) * 60 + int(minute)
                    if 'am' in finish:
                        time_split = re.compile('(.+?):(.+?)am').findall(str(finish))
                        for hour, minute in time_split:
                            finish_number = (int(hour) * 60) + int(minute)
                    elif 'pm' in finish:
                        time_split = re.compile('(.+?):(.+?)pm').findall(str(finish))
                        for hour, minute in time_split:
                            if hour == '12':
                                finish_number = (int(hour) * 60) + int(minute)
                            else:
                                finish_number = (int(hour) + 12) * 60 + int(minute)
                    if int(start_number) < int(time_now_number) < int(finish_number):
                        if not extra or extra == '':
                            clean_channel = channel.replace('BBC1 London', 'BBC1').replace('BBC2 London','BBC2').replace('ITV London', 'ITV1')
                            Menu(clean_channel.encode('utf-8') + ': ' + show_info.encode('utf-8'), '', 7,'', '',show_no+'\n'+info, clean_channel.replace('HD',''))
                            if len(Pass_List)<=1:
                                setView('movies', 'INFO2')
                                Pass_List.append('a')
                        else:
                            clean_channel = channel.replace('BBC1 London', 'BBC1').replace('BBC2 London','BBC2').replace('ITV London', 'ITV1')
                            clean_extra = extra.replace('BBC1 London', 'BBC1').replace('BBC2 London','BBC2').replace('ITV London','ITV1')
                            if clean_extra == clean_channel:
                                Menu(clean_channel.encode('utf-8') + ': ' + show_info.encode('utf-8'), '', 7,'', '',show_no+'\n'+info, clean_channel.replace('HD',''))
                                if len(Pass_List)<=1:
                                    setView('movies', 'INFO2')
                                    Pass_List.append('a')                            
                            else:
                                pass
    except:
        pass
		
def search_split(extra):
    search_next(extra.lower().replace('hd', '').replace(' ', '').replace('christmasgold','gold'))
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = ''
    link = ''
    try:
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
    except:
        pass
    if link != '':
        return link
    else:
        link = 'Opened'
        return link	
					
def Big_Resolve(name,url):
	import urlresolver
	try:
		resolved_url = urlresolver.resolve(url)
		xbmc.Player().play(resolved_url, xbmcgui.ListItem(name))
	except:
		xbmc.Player().play(url, xbmcgui.ListItem(name))
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
					
def Menu(name, url, mode, iconimage, fanart, description, extra, showcontext=True, allinfo={}):
    if iconimage == '':
        iconimage = ICON
    elif iconimage == ' ':
        iconimage = ICON
    if fanart == '':
        fanart = FANART
    elif fanart == ' ':
        fanart = FANART
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
        fanart) + "&description=" + urllib.quote_plus(description) + "&extra=" + urllib.quote_plus(extra)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("Fanart_Image", fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def Play(name, url, mode, iconimage, fanart, description, extra, showcontext=True, allinfo={}):
    if iconimage == '':
        iconimage = ICON
    elif iconimage == ' ':
        iconimage = ICON
    if fanart == '':
        fanart = FANART
    elif fanart == ' ':
        fanart = FANART
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
        fanart) + "&description=" + urllib.quote_plus(description) + "&extra=" + urllib.quote_plus(extra)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("Fanart_Image", fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

params=get_params()
url=None
name=None
iconimage=None
mode=None
description=None
extra=None
fanart=None
fav_mode=None
regexs=None
playlist=None

try:
    regexs=params["regexs"]
except:
    pass

try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
    extra=urllib.unquote_plus(params["extra"])
except:
    pass
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
    playitem=urllib.unquote_plus(params["playitem"])
except:
    pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('||',','))
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass

if mode == None: Main_Menu()
elif mode == 1: Search_Ultra()
elif mode == 2: tv_guide()
elif mode == 3: M3u8()
elif mode == 4: by_country()
elif mode == 5: Select_Type()
elif mode == 6: tvguide_co_uk(url)
elif mode == 7: search_split(extra)
elif mode == 8: Get_Channel(url)
elif mode == 9: Get_Playlink(name,url)
elif mode == 10: Big_Resolve(name,url)
elif mode == 11: WhatsOnCOUK(url,extra)
elif mode == 12: m3u8_single(url)
elif mode == 13: Todays_Sports()
elif mode == 14: Football_Highlights()
elif mode == 15: Get_the_rows(url,iconimage)
elif mode == 16: footytube(url)
elif mode == 17: footytube_leagues(name)
elif mode == 18: footytube_teams(url)
elif mode == 19: footytube_videos(url)
elif mode == 20: footytube_frame(name,url)
elif mode == 21: get_Multi_Links(url,iconimage)
elif mode == 22: get_All_Rows(url,iconimage)
elif mode == 23: get_PLAYlink(url)
elif mode == 24: Todays_Football()
elif mode == 25: Live_On_Sat(url)
elif mode == 26: Search_Channels_Mainstream(url)
elif mode == 27: Mama_hd()
elif mode == 28: Search()
elif mode == 29: WizHDMenu(url,iconimage,fanart)
elif mode == 30: Wiz_Get_url(url)
elif mode == 31: GetSublinks(name,url,iconimage,fanart)
elif mode == 32: Search_options()
elif mode == 33: Search_Create()
elif mode == 34: search_next(name)
elif mode == 35: Streamhd()

elif mode == 1201: freeview_play(url)
elif mode == 1202: tvplayer(name,url)

	
xbmcplugin.endOfDirectory(int(sys.argv[1]))
